var pinType = {
  GPIOI: 0,
  GPIOO: 1,
  ADC: 2,
  PWM: 3
};